// Advanced To-Do List - JavaScript

// Global variables
let tasks = [];
let categories = ['general', 'work', 'personal', 'shopping', 'health'];
let currentFilter = 'all';
let currentCategory = null;
let currentSort = 'created';
let sortAscending = false;
let editingTaskId = null;
let darkMode = false;

// Task class
class Task {
    constructor(text, category = 'general', priority = 'medium', dueDate = null) {
        this.id = Date.now() + Math.random();
        this.text = text;
        this.category = category;
        this.priority = priority;
        this.completed = false;
        this.createdAt = new Date();
        this.dueDate = dueDate ? new Date(dueDate) : null;
        this.notes = '';
        this.completedAt = null;
    }
    
    toggle() {
        this.completed = !this.completed;
        this.completedAt = this.completed ? new Date() : null;
    }
    
    isOverdue() {
        if (!this.dueDate || this.completed) return false;
        return new Date() > this.dueDate;
    }
    
    getDaysUntilDue() {
        if (!this.dueDate) return null;
        const now = new Date();
        const diffTime = this.dueDate - now;
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadData();
    updateUI();
});

function initializeApp() {
    // Load theme preference
    const savedTheme = localStorage.getItem('todoTheme');
    if (savedTheme === 'dark') {
        toggleDarkMode();
    }
    
    // Set default due date to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    document.getElementById('taskDueDate').value = tomorrow.toISOString().slice(0, 16);
    
    // Initialize categories
    updateCategorySelects();
    renderCategories();
}

function setupEventListeners() {
    // Task input
    document.getElementById('addTaskBtn').addEventListener('click', addTask);
    document.getElementById('taskInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') addTask();
    });
    
    // Dark mode toggle
    document.getElementById('darkModeToggle').addEventListener('click', toggleDarkMode);
    
    // Filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            setFilter(this.dataset.filter);
        });
    });
    
    // Search
    document.getElementById('searchInput').addEventListener('input', handleSearch);
    document.getElementById('clearSearch').addEventListener('click', clearSearch);
    
    // Sort
    document.getElementById('sortSelect').addEventListener('change', handleSort);
    document.getElementById('sortOrder').addEventListener('click', toggleSortOrder);
    
    // Categories
    document.getElementById('addCategoryBtn').addEventListener('click', addCategory);
    document.getElementById('newCategoryInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') addCategory();
    });
    
    // Modal controls
    document.getElementById('statsBtn').addEventListener('click', showStatsModal);
    document.getElementById('exportBtn').addEventListener('click', exportTasks);
    document.getElementById('importBtn').addEventListener('click', () => {
        document.getElementById('importFile').click();
    });
    document.getElementById('importFile').addEventListener('change', importTasks);
    
    // Close modals when clicking outside
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeAllModals();
        }
    });
}

// Task management functions
function addTask() {
    const text = document.getElementById('taskInput').value.trim();
    const category = document.getElementById('taskCategory').value;
    const priority = document.getElementById('taskPriority').value;
    const dueDate = document.getElementById('taskDueDate').value;
    
    if (!text) {
        showNotification('Please enter a task description', 'warning');
        return;
    }
    
    const task = new Task(text, category, priority, dueDate);
    tasks.push(task);
    
    // Clear form
    document.getElementById('taskInput').value = '';
    document.getElementById('taskDueDate').value = '';
    
    saveData();
    updateUI();
    showNotification('Task added successfully!', 'success');
}

function deleteTask(taskId) {
    if (confirm('Are you sure you want to delete this task?')) {
        tasks = tasks.filter(task => task.id !== taskId);
        saveData();
        updateUI();
        showNotification('Task deleted', 'success');
    }
}

function toggleTask(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
        task.toggle();
        saveData();
        updateUI();
        
        if (task.completed) {
            showNotification('Task completed! 🎉', 'success');
            updateStreak();
        }
    }
}

function editTask(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    
    editingTaskId = taskId;
    
    // Populate edit form
    document.getElementById('editTaskText').value = task.text;
    document.getElementById('editTaskCategory').value = task.category;
    document.getElementById('editTaskPriority').value = task.priority;
    document.getElementById('editTaskDueDate').value = task.dueDate ? 
        task.dueDate.toISOString().slice(0, 16) : '';
    document.getElementById('editTaskNotes').value = task.notes || '';
    
    // Update category options in edit modal
    updateEditCategorySelect();
    
    // Show modal
    document.getElementById('editModal').classList.add('show');
}

function saveTaskEdit() {
    const task = tasks.find(t => t.id === editingTaskId);
    if (!task) return;
    
    const text = document.getElementById('editTaskText').value.trim();
    if (!text) {
        showNotification('Task description cannot be empty', 'warning');
        return;
    }
    
    task.text = text;
    task.category = document.getElementById('editTaskCategory').value;
    task.priority = document.getElementById('editTaskPriority').value;
    task.notes = document.getElementById('editTaskNotes').value;
    
    const dueDateValue = document.getElementById('editTaskDueDate').value;
    task.dueDate = dueDateValue ? new Date(dueDateValue) : null;
    
    saveData();
    updateUI();
    closeEditModal();
    showNotification('Task updated successfully!', 'success');
}

function closeEditModal() {
    document.getElementById('editModal').classList.remove('show');
    editingTaskId = null;
}

// Category management
function addCategory() {
    const categoryName = document.getElementById('newCategoryInput').value.trim().toLowerCase();
    
    if (!categoryName) {
        showNotification('Please enter a category name', 'warning');
        return;
    }
    
    if (categories.includes(categoryName)) {
        showNotification('Category already exists', 'warning');
        return;
    }
    
    categories.push(categoryName);
    document.getElementById('newCategoryInput').value = '';
    
    updateCategorySelects();
    renderCategories();
    saveData();
    showNotification('Category added!', 'success');
}

function deleteCategory(categoryName) {
    if (categories.length <= 1) {
        showNotification('Cannot delete the last category', 'warning');
        return;
    }
    
    if (confirm(`Delete category "${categoryName}"? Tasks in this category will be moved to "general".`)) {
        // Move tasks to general category
        tasks.forEach(task => {
            if (task.category === categoryName) {
                task.category = 'general';
            }
        });
        
        categories = categories.filter(cat => cat !== categoryName);
        
        updateCategorySelects();
        renderCategories();
        saveData();
        updateUI();
        showNotification('Category deleted', 'success');
    }
}

function setActiveCategory(categoryName) {
    currentCategory = currentCategory === categoryName ? null : categoryName;
    renderCategories();
    updateUI();
}

// Filtering and sorting
function setFilter(filter) {
    currentFilter = filter;
    
    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-filter="${filter}"]`).classList.add('active');
    
    updateUI();
}

function handleSearch() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    const clearBtn = document.getElementById('clearSearch');
    
    if (searchTerm) {
        clearBtn.style.display = 'block';
    } else {
        clearBtn.style.display = 'none';
    }
    
    updateUI();
}

function clearSearch() {
    document.getElementById('searchInput').value = '';
    document.getElementById('clearSearch').style.display = 'none';
    updateUI();
}

function handleSort() {
    currentSort = document.getElementById('sortSelect').value;
    updateUI();
}

function toggleSortOrder() {
    sortAscending = !sortAscending;
    const icon = document.querySelector('#sortOrder i');
    icon.className = sortAscending ? 'fas fa-sort-amount-up' : 'fas fa-sort-amount-down';
    updateUI();
}

function getFilteredTasks() {
    let filteredTasks = [...tasks];
    
    // Apply category filter
    if (currentCategory) {
        filteredTasks = filteredTasks.filter(task => task.category === currentCategory);
    }
    
    // Apply status filter
    switch (currentFilter) {
        case 'pending':
            filteredTasks = filteredTasks.filter(task => !task.completed);
            break;
        case 'completed':
            filteredTasks = filteredTasks.filter(task => task.completed);
            break;
        case 'overdue':
            filteredTasks = filteredTasks.filter(task => task.isOverdue());
            break;
    }
    
    // Apply search filter
    const searchTerm = document.getElementById('searchInput').value.trim().toLowerCase();
    if (searchTerm) {
        filteredTasks = filteredTasks.filter(task => 
            task.text.toLowerCase().includes(searchTerm) ||
            task.category.toLowerCase().includes(searchTerm) ||
            (task.notes && task.notes.toLowerCase().includes(searchTerm))
        );
    }
    
    // Apply sorting
    filteredTasks.sort((a, b) => {
        let comparison = 0;
        
        switch (currentSort) {
            case 'created':
                comparison = a.createdAt - b.createdAt;
                break;
            case 'dueDate':
                if (!a.dueDate && !b.dueDate) comparison = 0;
                else if (!a.dueDate) comparison = 1;
                else if (!b.dueDate) comparison = -1;
                else comparison = a.dueDate - b.dueDate;
                break;
            case 'priority':
                const priorityOrder = { high: 3, medium: 2, low: 1 };
                comparison = priorityOrder[b.priority] - priorityOrder[a.priority];
                break;
            case 'alphabetical':
                comparison = a.text.localeCompare(b.text);
                break;
        }
        
        return sortAscending ? comparison : -comparison;
    });
    
    return filteredTasks;
}

// UI update functions
function updateUI() {
    renderTasks();
    updateCounts();
    updateStats();
}

function renderTasks() {
    const taskList = document.getElementById('taskList');
    const emptyState = document.getElementById('emptyState');
    const filteredTasks = getFilteredTasks();
    
    if (filteredTasks.length === 0) {
        taskList.style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }
    
    taskList.style.display = 'block';
    emptyState.style.display = 'none';
    
    taskList.innerHTML = filteredTasks.map(task => createTaskHTML(task)).join('');
    
    // Add event listeners to task elements
    filteredTasks.forEach(task => {
        const taskElement = document.querySelector(`[data-task-id="${task.id}"]`);
        if (taskElement) {
            // Checkbox toggle
            const checkbox = taskElement.querySelector('.task-checkbox');
            checkbox.addEventListener('click', (e) => {
                e.stopPropagation();
                toggleTask(task.id);
            });
            
            // Edit button
            const editBtn = taskElement.querySelector('.edit-btn');
            if (editBtn) {
                editBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    editTask(task.id);
                });
            }
            
            // Delete button
            const deleteBtn = taskElement.querySelector('.delete-btn');
            if (deleteBtn) {
                deleteBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    deleteTask(task.id);
                });
            }
        }
    });
}

function createTaskHTML(task) {
    const daysUntilDue = task.getDaysUntilDue();
    const dueDateText = task.dueDate ? 
        (daysUntilDue === 0 ? 'Due today' :
         daysUntilDue === 1 ? 'Due tomorrow' :
         daysUntilDue === -1 ? 'Due yesterday' :
         daysUntilDue > 0 ? `Due in ${daysUntilDue} days` :
         `Overdue by ${Math.abs(daysUntilDue)} days`) : '';
    
    return `
        <div class="task-item ${task.completed ? 'completed' : ''} ${task.isOverdue() ? 'overdue' : ''}" 
             data-task-id="${task.id}">
            <div class="task-header">
                <div class="task-checkbox ${task.completed ? 'checked' : ''}"></div>
                <div class="task-text ${task.completed ? 'completed' : ''}">${escapeHtml(task.text)}</div>
                <div class="task-priority ${task.priority}">${task.priority}</div>
                <div class="task-actions">
                    <button class="edit-btn" title="Edit task">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="delete-btn" title="Delete task">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            <div class="task-meta">
                <div>
                    <span class="task-category">${task.category}</span>
                    ${task.notes ? `<span title="${escapeHtml(task.notes)}"><i class="fas fa-sticky-note"></i></span>` : ''}
                </div>
                <div>
                    ${dueDateText ? `<span class="${task.isOverdue() ? 'text-danger' : ''}">${dueDateText}</span>` : ''}
                </div>
            </div>
        </div>
    `;
}

function updateCounts() {
    const all = tasks.length;
    const pending = tasks.filter(t => !t.completed).length;
    const completed = tasks.filter(t => t.completed).length;
    const overdue = tasks.filter(t => t.isOverdue()).length;
    
    document.getElementById('allCount').textContent = all;
    document.getElementById('pendingCount').textContent = pending;
    document.getElementById('completedCount').textContent = completed;
    document.getElementById('overdueCount').textContent = overdue;
}

function updateStats() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayTasks = tasks.filter(task => {
        const taskDate = new Date(task.createdAt);
        taskDate.setHours(0, 0, 0, 0);
        return taskDate.getTime() === today.getTime();
    }).length;
    
    const completionRate = tasks.length > 0 ? 
        Math.round((tasks.filter(t => t.completed).length / tasks.length) * 100) : 0;
    
    const streak = getCompletionStreak();
    
    document.getElementById('todayTasks').textContent = todayTasks;
    document.getElementById('completionRate').textContent = `${completionRate}%`;
    document.getElementById('streakCount').textContent = `${streak} days`;
}

function renderCategories() {
    const categoryList = document.getElementById('categoryList');
    
    categoryList.innerHTML = categories.map(category => `
        <div class="category-item ${currentCategory === category ? 'active' : ''}" 
             onclick="setActiveCategory('${category}')">
            <div style="display: flex; align-items: center;">
                <div class="category-color" style="background: ${getCategoryColor(category)};"></div>
                <span>${category}</span>
            </div>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <span class="count">${tasks.filter(t => t.category === category).length}</span>
                ${categories.length > 1 ? `
                    <button onclick="event.stopPropagation(); deleteCategory('${category}')" 
                            class="btn-icon" style="width: 1.5rem; height: 1.5rem; padding: 0.25rem;">
                        <i class="fas fa-times"></i>
                    </button>
                ` : ''}
            </div>
        </div>
    `).join('');
}

function updateCategorySelects() {
    const selects = ['taskCategory', 'editTaskCategory'];
    
    selects.forEach(selectId => {
        const select = document.getElementById(selectId);
        if (select) {
            const currentValue = select.value;
            select.innerHTML = categories.map(category => 
                `<option value="${category}">${category}</option>`
            ).join('');
            
            if (categories.includes(currentValue)) {
                select.value = currentValue;
            }
        }
    });
}

function updateEditCategorySelect() {
    const select = document.getElementById('editTaskCategory');
    select.innerHTML = categories.map(category =>
        `<option value="${category}">${category}</option>`
    ).join('');
}

// Utility functions
function getCategoryColor(category) {
    const colors = {
        general: '#6366f1',
        work: '#ef4444',
        personal: '#10b981',
        shopping: '#f59e0b',
        health: '#8b5cf6'
    };

    // Generate color for custom categories
    if (!colors[category]) {
        const hash = category.split('').reduce((a, b) => {
            a = ((a << 5) - a) + b.charCodeAt(0);
            return a & a;
        }, 0);
        const hue = Math.abs(hash) % 360;
        return `hsl(${hue}, 60%, 50%)`;
    }

    return colors[category];
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

// Dark mode
function toggleDarkMode() {
    darkMode = !darkMode;
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');

    const icon = document.querySelector('#darkModeToggle i');
    icon.className = darkMode ? 'fas fa-sun' : 'fas fa-moon';

    localStorage.setItem('todoTheme', darkMode ? 'dark' : 'light');
}

// Statistics and analytics
function getCompletionStreak() {
    const streak = localStorage.getItem('todoStreak');
    return streak ? parseInt(streak) : 0;
}

function updateStreak() {
    const today = new Date().toDateString();
    const lastCompletionDate = localStorage.getItem('lastCompletionDate');

    if (lastCompletionDate !== today) {
        const currentStreak = getCompletionStreak();
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);

        if (lastCompletionDate === yesterday.toDateString()) {
            // Continue streak
            localStorage.setItem('todoStreak', (currentStreak + 1).toString());
        } else {
            // Start new streak
            localStorage.setItem('todoStreak', '1');
        }

        localStorage.setItem('lastCompletionDate', today);
    }
}

function showStatsModal() {
    updateStatsModal();
    document.getElementById('statsModal').classList.add('show');
}

function updateStatsModal() {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.completed).length;
    const pendingTasks = tasks.filter(t => !t.completed).length;
    const currentStreak = getCompletionStreak();

    document.getElementById('totalTasksStat').textContent = totalTasks;
    document.getElementById('completedTasksStat').textContent = completedTasks;
    document.getElementById('pendingTasksStat').textContent = pendingTasks;
    document.getElementById('currentStreakStat').textContent = currentStreak;

    // Simple progress chart (you could integrate Chart.js for more advanced charts)
    drawProgressChart();
}

function drawProgressChart() {
    const canvas = document.getElementById('progressChart');
    const ctx = canvas.getContext('2d');

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Get last 7 days data
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        date.setHours(0, 0, 0, 0);

        const dayTasks = tasks.filter(task => {
            const taskDate = new Date(task.createdAt);
            taskDate.setHours(0, 0, 0, 0);
            return taskDate.getTime() === date.getTime();
        });

        const completed = dayTasks.filter(t => t.completed).length;

        last7Days.push({
            date: date,
            completed: completed,
            total: dayTasks.length
        });
    }

    // Draw simple bar chart
    const barWidth = canvas.width / 7;
    const maxHeight = canvas.height - 40;
    const maxTasks = Math.max(...last7Days.map(d => d.total), 1);

    last7Days.forEach((day, index) => {
        const x = index * barWidth;
        const height = (day.completed / maxTasks) * maxHeight;
        const y = canvas.height - height - 20;

        // Draw bar
        ctx.fillStyle = '#6366f1';
        ctx.fillRect(x + 10, y, barWidth - 20, height);

        // Draw day label
        ctx.fillStyle = '#64748b';
        ctx.font = '12px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(
            day.date.toLocaleDateString('en-US', { weekday: 'short' }),
            x + barWidth / 2,
            canvas.height - 5
        );

        // Draw count
        if (day.completed > 0) {
            ctx.fillStyle = '#ffffff';
            ctx.fillText(day.completed, x + barWidth / 2, y + height / 2 + 4);
        }
    });
}

function closeStatsModal() {
    document.getElementById('statsModal').classList.remove('show');
}

// Import/Export functionality
function exportTasks() {
    const data = {
        tasks: tasks,
        categories: categories,
        exportDate: new Date().toISOString(),
        version: '1.0'
    };

    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });

    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `todo-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();

    showNotification('Tasks exported successfully!', 'success');
}

function importTasks(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);

            if (!data.tasks || !Array.isArray(data.tasks)) {
                throw new Error('Invalid file format');
            }

            const confirmMessage = `This will replace all current tasks (${tasks.length}) with imported tasks (${data.tasks.length}). Continue?`;

            if (confirm(confirmMessage)) {
                // Import tasks
                tasks = data.tasks.map(taskData => {
                    const task = new Task(taskData.text, taskData.category, taskData.priority);
                    Object.assign(task, taskData);

                    // Convert date strings back to Date objects
                    task.createdAt = new Date(task.createdAt);
                    task.dueDate = task.dueDate ? new Date(task.dueDate) : null;
                    task.completedAt = task.completedAt ? new Date(task.completedAt) : null;

                    return task;
                });

                // Import categories if available
                if (data.categories && Array.isArray(data.categories)) {
                    categories = [...new Set([...categories, ...data.categories])];
                }

                saveData();
                updateCategorySelects();
                renderCategories();
                updateUI();

                showNotification(`Successfully imported ${tasks.length} tasks!`, 'success');
            }
        } catch (error) {
            showNotification('Error importing file. Please check the file format.', 'error');
            console.error('Import error:', error);
        }
    };

    reader.readAsText(file);
    event.target.value = ''; // Reset file input
}

// Notifications
function showNotification(message, type = 'info') {
    const container = document.getElementById('notificationContainer');
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
    `;

    container.appendChild(notification);

    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.animation = 'notificationSlideOut 0.3s ease-in forwards';
            setTimeout(() => {
                if (notification.parentNode) {
                    container.removeChild(notification);
                }
            }, 300);
        }
    }, 3000);
}

function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Modal management
function closeAllModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('show');
    });
}

// Data persistence
function saveData() {
    const data = {
        tasks: tasks,
        categories: categories,
        lastSaved: new Date().toISOString()
    };

    localStorage.setItem('todoAppData', JSON.stringify(data));
}

function loadData() {
    const savedData = localStorage.getItem('todoAppData');

    if (savedData) {
        try {
            const data = JSON.parse(savedData);

            if (data.tasks) {
                tasks = data.tasks.map(taskData => {
                    const task = new Task(taskData.text, taskData.category, taskData.priority);
                    Object.assign(task, taskData);

                    // Convert date strings back to Date objects
                    task.createdAt = new Date(task.createdAt);
                    task.dueDate = task.dueDate ? new Date(task.dueDate) : null;
                    task.completedAt = task.completedAt ? new Date(task.completedAt) : null;

                    return task;
                });
            }

            if (data.categories) {
                categories = data.categories;
            }
        } catch (error) {
            console.error('Error loading saved data:', error);
            showNotification('Error loading saved data', 'error');
        }
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + Enter to add task
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        if (document.getElementById('taskInput') === document.activeElement) {
            addTask();
        }
    }

    // Escape to close modals
    if (e.key === 'Escape') {
        closeAllModals();
    }

    // Ctrl/Cmd + D for dark mode
    if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
        e.preventDefault();
        toggleDarkMode();
    }
});

// Add CSS animation for notification slide out
const style = document.createElement('style');
style.textContent = `
    @keyframes notificationSlideOut {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100%);
        }
    }
`;
document.head.appendChild(style);
