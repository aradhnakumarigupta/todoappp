// Performance Optimizations for Advanced To-Do List

// Critical performance enhancements
(function() {
    'use strict';
    
    // Preload critical resources
    function preloadCriticalResources() {
        const criticalResources = [
            'todo-style.css',
            'todo-script.js',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/webfonts/fa-solid-900.woff2'
        ];
        
        criticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.href = resource;
            link.as = resource.endsWith('.css') ? 'style' : 
                     resource.endsWith('.js') ? 'script' : 'font';
            if (link.as === 'font') {
                link.crossOrigin = 'anonymous';
            }
            document.head.appendChild(link);
        });
    }
    
    // Optimize images and icons
    function optimizeImages() {
        // Lazy load images when they come into view
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        observer.unobserve(img);
                    }
                });
            });
            
            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    }
    
    // Debounce function for performance
    function debounce(func, wait, immediate) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                timeout = null;
                if (!immediate) func.apply(this, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(this, args);
        };
    }
    
    // Throttle function for scroll events
    function throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    // Virtual scrolling for large task lists
    class VirtualScroller {
        constructor(container, itemHeight = 80, bufferSize = 5) {
            this.container = container;
            this.itemHeight = itemHeight;
            this.bufferSize = bufferSize;
            this.scrollTop = 0;
            this.containerHeight = container.clientHeight;
            this.items = [];
            this.renderedItems = new Map();
            
            this.setupScrollListener();
        }
        
        setupScrollListener() {
            this.container.addEventListener('scroll', throttle(() => {
                this.scrollTop = this.container.scrollTop;
                this.render();
            }, 16)); // ~60fps
        }
        
        setItems(items) {
            this.items = items;
            this.render();
        }
        
        render() {
            const visibleStart = Math.floor(this.scrollTop / this.itemHeight);
            const visibleEnd = Math.min(
                visibleStart + Math.ceil(this.containerHeight / this.itemHeight) + this.bufferSize,
                this.items.length
            );
            
            // Remove items that are no longer visible
            this.renderedItems.forEach((element, index) => {
                if (index < visibleStart || index >= visibleEnd) {
                    element.remove();
                    this.renderedItems.delete(index);
                }
            });
            
            // Add newly visible items
            for (let i = visibleStart; i < visibleEnd; i++) {
                if (!this.renderedItems.has(i) && this.items[i]) {
                    const element = this.createItemElement(this.items[i], i);
                    this.renderedItems.set(i, element);
                    this.container.appendChild(element);
                }
            }
        }
        
        createItemElement(item, index) {
            const element = document.createElement('div');
            element.style.position = 'absolute';
            element.style.top = `${index * this.itemHeight}px`;
            element.style.height = `${this.itemHeight}px`;
            element.style.width = '100%';
            element.innerHTML = this.renderItem(item);
            return element;
        }
        
        renderItem(item) {
            // This should be overridden by the implementation
            return `<div>${item.text}</div>`;
        }
    }
    
    // Memory management
    function optimizeMemoryUsage() {
        // Clean up old event listeners
        const cleanupOldListeners = () => {
            document.querySelectorAll('[data-cleanup]').forEach(element => {
                element.removeEventListener('click', element._clickHandler);
                element.remove();
            });
        };
        
        // Garbage collection hints
        const suggestGarbageCollection = () => {
            if (window.gc && typeof window.gc === 'function') {
                window.gc();
            }
        };
        
        // Clean up every 5 minutes
        setInterval(() => {
            cleanupOldListeners();
            suggestGarbageCollection();
        }, 5 * 60 * 1000);
    }
    
    // Optimize localStorage operations
    function optimizeLocalStorage() {
        const localStorageCache = new Map();
        const CACHE_EXPIRY = 5 * 60 * 1000; // 5 minutes
        
        const originalGetItem = localStorage.getItem.bind(localStorage);
        const originalSetItem = localStorage.setItem.bind(localStorage);
        
        localStorage.getItem = function(key) {
            const cached = localStorageCache.get(key);
            if (cached && Date.now() - cached.timestamp < CACHE_EXPIRY) {
                return cached.value;
            }
            
            const value = originalGetItem(key);
            localStorageCache.set(key, {
                value: value,
                timestamp: Date.now()
            });
            
            return value;
        };
        
        localStorage.setItem = function(key, value) {
            localStorageCache.set(key, {
                value: value,
                timestamp: Date.now()
            });
            
            return originalSetItem(key, value);
        };
    }
    
    // Critical CSS inlining
    function inlineCriticalCSS() {
        const criticalCSS = `
            /* Critical above-the-fold styles */
            body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
            .app-container { min-height: 100vh; }
            .app-header { background: #fff; border-bottom: 1px solid #e2e8f0; }
            .loading-spinner { 
                display: inline-block; width: 20px; height: 20px; 
                border: 3px solid #f3f3f3; border-top: 3px solid #6366f1; 
                border-radius: 50%; animation: spin 1s linear infinite; 
            }
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        `;
        
        const style = document.createElement('style');
        style.textContent = criticalCSS;
        document.head.insertBefore(style, document.head.firstChild);
    }
    
    // Resource hints
    function addResourceHints() {
        const hints = [
            { rel: 'dns-prefetch', href: '//cdnjs.cloudflare.com' },
            { rel: 'preconnect', href: 'https://cdnjs.cloudflare.com', crossorigin: true },
            { rel: 'prefetch', href: '/manifest.json' }
        ];
        
        hints.forEach(hint => {
            const link = document.createElement('link');
            Object.assign(link, hint);
            document.head.appendChild(link);
        });
    }
    
    // Performance monitoring
    function setupPerformanceMonitoring() {
        if ('performance' in window) {
            // Monitor Core Web Vitals
            function measureCLS() {
                let clsValue = 0;
                let clsEntries = [];
                
                const observer = new PerformanceObserver((entryList) => {
                    for (const entry of entryList.getEntries()) {
                        if (!entry.hadRecentInput) {
                            clsEntries.push(entry);
                            clsValue += entry.value;
                        }
                    }
                });
                
                observer.observe({ entryTypes: ['layout-shift'] });
                
                return () => clsValue;
            }
            
            function measureLCP() {
                let lcpValue = 0;
                
                const observer = new PerformanceObserver((entryList) => {
                    const entries = entryList.getEntries();
                    const lastEntry = entries[entries.length - 1];
                    lcpValue = lastEntry.startTime;
                });
                
                observer.observe({ entryTypes: ['largest-contentful-paint'] });
                
                return () => lcpValue;
            }
            
            function measureFID() {
                let fidValue = 0;
                
                const observer = new PerformanceObserver((entryList) => {
                    for (const entry of entryList.getEntries()) {
                        fidValue = entry.processingStart - entry.startTime;
                    }
                });
                
                observer.observe({ entryTypes: ['first-input'] });
                
                return () => fidValue;
            }
            
            // Initialize measurements
            const getCLS = measureCLS();
            const getLCP = measureLCP();
            const getFID = measureFID();
            
            // Report metrics after page load
            window.addEventListener('load', () => {
                setTimeout(() => {
                    const metrics = {
                        cls: getCLS(),
                        lcp: getLCP(),
                        fid: getFID(),
                        loadTime: performance.timing.loadEventEnd - performance.timing.navigationStart
                    };
                    
                    console.log('Performance Metrics:', metrics);
                    
                    // Store metrics for analytics
                    localStorage.setItem('performanceMetrics', JSON.stringify(metrics));
                }, 1000);
            });
        }
    }
    
    // Optimize animations
    function optimizeAnimations() {
        // Use requestAnimationFrame for smooth animations
        const animationQueue = [];
        let isAnimating = false;
        
        function processAnimationQueue() {
            if (animationQueue.length === 0) {
                isAnimating = false;
                return;
            }
            
            const animation = animationQueue.shift();
            animation();
            
            requestAnimationFrame(processAnimationQueue);
        }
        
        window.queueAnimation = function(animationFn) {
            animationQueue.push(animationFn);
            
            if (!isAnimating) {
                isAnimating = true;
                requestAnimationFrame(processAnimationQueue);
            }
        };
        
        // Reduce motion for users who prefer it
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            document.documentElement.style.setProperty('--animation-duration', '0.01ms');
        }
    }
    
    // Initialize all optimizations
    function initializeOptimizations() {
        // Run critical optimizations immediately
        inlineCriticalCSS();
        addResourceHints();
        
        // Run other optimizations after DOM is ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                preloadCriticalResources();
                optimizeImages();
                optimizeMemoryUsage();
                optimizeLocalStorage();
                setupPerformanceMonitoring();
                optimizeAnimations();
            });
        } else {
            preloadCriticalResources();
            optimizeImages();
            optimizeMemoryUsage();
            optimizeLocalStorage();
            setupPerformanceMonitoring();
            optimizeAnimations();
        }
    }
    
    // Export utilities for use in main app
    window.PerformanceUtils = {
        debounce,
        throttle,
        VirtualScroller,
        queueAnimation: window.queueAnimation
    };
    
    // Initialize
    initializeOptimizations();
    
})();
