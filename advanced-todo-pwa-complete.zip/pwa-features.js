// PWA Features - Enhanced functionality for web deployment

// Global PWA variables
let deferredPrompt;
let swRegistration;
let isOnline = navigator.onLine;

// Initialize PWA features when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializePWA();
    setupNetworkDetection();
    setupInstallPrompt();
    setupShareAPI();
    handleURLParams();
});

// Initialize PWA functionality
async function initializePWA() {
    // Register service worker
    if ('serviceWorker' in navigator) {
        try {
            swRegistration = await navigator.serviceWorker.register('/sw.js');
            console.log('PWA: Service Worker registered successfully');
            
            // Check for updates
            swRegistration.addEventListener('updatefound', handleServiceWorkerUpdate);
            
            // Listen for messages from service worker
            navigator.serviceWorker.addEventListener('message', handleServiceWorkerMessage);
            
        } catch (error) {
            console.error('PWA: Service Worker registration failed:', error);
        }
    }
    
    // Setup notification permissions
    if ('Notification' in window) {
        setupNotifications();
    }
    
    // Setup background sync
    if ('serviceWorker' in navigator && 'sync' in window.ServiceWorkerRegistration.prototype) {
        setupBackgroundSync();
    }
}

// Network detection and offline handling
function setupNetworkDetection() {
    function updateConnectionStatus() {
        isOnline = navigator.onLine;
        const statusElement = document.getElementById('connectionStatus');
        
        if (statusElement) {
            statusElement.textContent = isOnline ? 'Online' : 'Offline';
            statusElement.style.color = isOnline ? 'var(--success-color)' : 'var(--warning-color)';
        }
        
        // Show notification about connection status
        if (!isOnline) {
            showNotification('You are offline. The app will continue to work with cached data.', 'warning');
        } else {
            showNotification('Connection restored!', 'success');
        }
        
        // Update UI based on connection
        updateOfflineUI();
    }
    
    window.addEventListener('online', updateConnectionStatus);
    window.addEventListener('offline', updateConnectionStatus);
    
    // Initial status
    updateConnectionStatus();
}

function updateOfflineUI() {
    const shareBtn = document.getElementById('shareBtn');
    const importBtn = document.getElementById('importBtn');
    
    if (!isOnline) {
        // Disable features that require network
        if (shareBtn) shareBtn.style.opacity = '0.5';
        if (importBtn) importBtn.title = 'Import unavailable offline';
    } else {
        // Re-enable features
        if (shareBtn) shareBtn.style.opacity = '1';
        if (importBtn) importBtn.title = 'Import Tasks';
    }
}

// Install prompt handling
function setupInstallPrompt() {
    window.addEventListener('beforeinstallprompt', (e) => {
        console.log('PWA: Install prompt triggered');
        e.preventDefault();
        deferredPrompt = e;
        
        // Show custom install prompt after a delay
        setTimeout(showInstallPrompt, 3000);
    });
    
    // Handle install button click
    document.getElementById('installBtn')?.addEventListener('click', async () => {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            console.log('PWA: Install prompt outcome:', outcome);
            
            if (outcome === 'accepted') {
                hideInstallPrompt();
                showNotification('App installed successfully!', 'success');
            }
            
            deferredPrompt = null;
        }
    });
    
    // Handle dismiss button
    document.getElementById('dismissInstall')?.addEventListener('click', () => {
        hideInstallPrompt();
        localStorage.setItem('installPromptDismissed', Date.now());
    });
    
    // Check if app is already installed
    window.addEventListener('appinstalled', () => {
        console.log('PWA: App was installed');
        hideInstallPrompt();
        showNotification('Welcome to the installed app!', 'success');
    });
}

function showInstallPrompt() {
    // Don't show if recently dismissed
    const dismissed = localStorage.getItem('installPromptDismissed');
    if (dismissed && Date.now() - parseInt(dismissed) < 7 * 24 * 60 * 60 * 1000) {
        return;
    }
    
    // Don't show if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
        return;
    }
    
    const prompt = document.getElementById('installPrompt');
    if (prompt && deferredPrompt) {
        prompt.style.display = 'flex';
    }
}

function hideInstallPrompt() {
    const prompt = document.getElementById('installPrompt');
    if (prompt) {
        prompt.style.display = 'none';
    }
}

// Service worker update handling
function handleServiceWorkerUpdate() {
    const updateNotification = document.getElementById('updateAvailable');
    if (updateNotification) {
        updateNotification.style.display = 'flex';
    }
    
    document.getElementById('updateBtn')?.addEventListener('click', () => {
        if (swRegistration && swRegistration.waiting) {
            swRegistration.waiting.postMessage({ type: 'SKIP_WAITING' });
        }
    });
}

function handleServiceWorkerMessage(event) {
    if (event.data && event.data.type === 'SW_UPDATED') {
        window.location.reload();
    }
}

// Web Share API
function setupShareAPI() {
    const shareBtn = document.getElementById('shareBtn');
    
    if (navigator.share && shareBtn) {
        shareBtn.style.display = 'block';
        shareBtn.addEventListener('click', shareApp);
    }
}

async function shareApp() {
    if (navigator.share) {
        try {
            await navigator.share({
                title: 'Advanced To-Do List',
                text: 'Check out this amazing task management app!',
                url: window.location.href
            });
            console.log('PWA: App shared successfully');
        } catch (error) {
            console.log('PWA: Share cancelled or failed:', error);
        }
    } else {
        // Fallback: copy to clipboard
        try {
            await navigator.clipboard.writeText(window.location.href);
            showNotification('App link copied to clipboard!', 'success');
        } catch (error) {
            console.error('PWA: Failed to copy link:', error);
        }
    }
}

// Handle URL parameters for deep linking
function handleURLParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const action = urlParams.get('action');
    
    switch (action) {
        case 'new-task':
            // Focus on task input
            setTimeout(() => {
                document.getElementById('taskInput')?.focus();
            }, 500);
            break;
            
        case 'stats':
            // Open statistics modal
            setTimeout(() => {
                showStatsModal();
            }, 500);
            break;
    }
}

// Notification permissions and handling
function setupNotifications() {
    // Request permission if not already granted
    if (Notification.permission === 'default') {
        setTimeout(() => {
            requestNotificationPermission();
        }, 5000);
    }
}

async function requestNotificationPermission() {
    try {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
            showNotification('Notifications enabled! You\'ll get reminders for due tasks.', 'success');
        }
    } catch (error) {
        console.error('PWA: Notification permission error:', error);
    }
}

// Background sync setup
function setupBackgroundSync() {
    // Register for background sync when tasks are modified offline
    if (swRegistration && swRegistration.sync) {
        // This would be used for syncing data when back online
        console.log('PWA: Background sync available');
    }
}

// Enhanced task notifications
function scheduleTaskNotification(task) {
    if (Notification.permission !== 'granted' || !task.dueDate) {
        return;
    }
    
    const now = new Date();
    const dueDate = new Date(task.dueDate);
    const timeDiff = dueDate.getTime() - now.getTime();
    
    // Schedule notification 1 hour before due date
    const notificationTime = timeDiff - (60 * 60 * 1000);
    
    if (notificationTime > 0) {
        setTimeout(() => {
            if ('serviceWorker' in navigator && swRegistration) {
                swRegistration.showNotification('Task Due Soon!', {
                    body: `"${task.text}" is due in 1 hour`,
                    icon: '/icons/icon-192x192.png',
                    badge: '/icons/icon-72x72.png',
                    tag: `task-${task.id}`,
                    requireInteraction: true,
                    actions: [
                        {
                            action: 'complete',
                            title: 'Mark Complete'
                        },
                        {
                            action: 'snooze',
                            title: 'Snooze 1h'
                        }
                    ]
                });
            }
        }, notificationTime);
    }
}

// Performance monitoring
function trackPerformance() {
    if ('performance' in window) {
        window.addEventListener('load', () => {
            const perfData = performance.getEntriesByType('navigation')[0];
            console.log('PWA: Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
        });
    }
}

// Analytics (privacy-friendly)
function trackUsage(action, category = 'app') {
    // Simple usage tracking without external services
    const usage = JSON.parse(localStorage.getItem('appUsage') || '{}');
    const today = new Date().toDateString();
    
    if (!usage[today]) {
        usage[today] = {};
    }
    
    if (!usage[today][category]) {
        usage[today][category] = {};
    }
    
    usage[today][category][action] = (usage[today][category][action] || 0) + 1;
    
    localStorage.setItem('appUsage', JSON.stringify(usage));
}

// Keyboard shortcuts for PWA
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + I for install prompt
    if ((e.ctrlKey || e.metaKey) && e.key === 'i' && deferredPrompt) {
        e.preventDefault();
        showInstallPrompt();
    }
    
    // Ctrl/Cmd + S for share
    if ((e.ctrlKey || e.metaKey) && e.key === 's' && navigator.share) {
        e.preventDefault();
        shareApp();
    }
});

// Cleanup and optimization
window.addEventListener('beforeunload', () => {
    // Clean up old usage data (keep only last 30 days)
    const usage = JSON.parse(localStorage.getItem('appUsage') || '{}');
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    Object.keys(usage).forEach(date => {
        if (new Date(date) < thirtyDaysAgo) {
            delete usage[date];
        }
    });
    
    localStorage.setItem('appUsage', JSON.stringify(usage));
});

// Initialize performance tracking
trackPerformance();

// Export functions for use in main app
window.PWAFeatures = {
    scheduleTaskNotification,
    trackUsage,
    isOnline: () => isOnline,
    shareApp
};

console.log('PWA: Features initialized successfully');
